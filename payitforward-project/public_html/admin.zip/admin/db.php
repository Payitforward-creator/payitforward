<?php
    $conn = mysqli_connect("localhost", "yotamavi_root", "yotamavi", "yotamavi_root") or die('Error connecting database');
    $domain = "http://localhost/yotamavi2/";